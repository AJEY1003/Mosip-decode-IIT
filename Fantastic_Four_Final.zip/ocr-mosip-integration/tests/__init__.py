"""
Test modules for OCR-MOSIP integration
"""