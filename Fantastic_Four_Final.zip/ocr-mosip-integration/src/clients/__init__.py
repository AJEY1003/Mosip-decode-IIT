"""
Client modules for MOSIP, InjINet, and Inji Verify integration
"""