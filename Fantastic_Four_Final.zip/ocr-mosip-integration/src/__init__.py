"""
OCR-MOSIP Integration Package
OCR-driven solution for text extraction and data verification with MOSIP integration
"""

__version__ = "1.0.0"
__author__ = "OCR-MOSIP Integration Team"
__description__ = "OCR-driven solution for text extraction and data verification"