"""
Utility modules for QR code generation, analysis, and image processing
"""