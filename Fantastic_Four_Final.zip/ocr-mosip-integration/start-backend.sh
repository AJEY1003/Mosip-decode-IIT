#!/bin/bash
echo "Starting MOSIP ITR Assistant Backend Server..."
echo ""
echo "Make sure you have installed the requirements:"
echo "pip install -r requirements.txt"
echo ""
echo "Starting Flask application..."
python src/core/app.py